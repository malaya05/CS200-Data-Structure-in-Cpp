/*
(name header)
*/

#include "DArray.h"

// Definition function emptyArray


// Definition function appendArray


// Definition move constructor


// Definition move assignment operator
