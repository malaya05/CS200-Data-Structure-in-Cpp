
/*
	Alaya, Jason
	Almashash Swed,Jawad
	Mendoza, Moises

	CS A200
	Decomber 4, 2017

	Lab 8
*/
#include <iostream>
using namespace std;

// Declaration of function processStacks
void processStacks(int *a, int, int& leftTop, int& rightTop);
// Declaration of function printSmallValues
void printSmallValues(int *a, int leftTop);
// Declaration of function printLargeValues
void printLargeValues(int *a, int cap, int rightTop);

int main()
{
	int cap = 0; 
	int leftTop = 0;
	int rightTop=0;

	cout << "Enter max number of integers: ";	
	cin >> cap;

	int *a = new int[cap] ;

	// call to function processStacks
	processStacks(a, cap, leftTop, rightTop);
	// call to function printSmallValues
	 printSmallValues(a,  leftTop);
	// call to function printLargeValues
	 printLargeValues(a, cap, rightTop);
	// what else?
	delete[] a;


	cout << endl;
	system("Pause");
	return 0;
}

// Definition of function processStacks
void processStacks(int *a, int cap, int& leftTop, int& rightTop)
{
	leftTop = 0;
	rightTop = cap - 1;
	int x = 0;
	cout << "Enter integers (-1 to quit): " << endl;
	cin >> x;

	while (x != -1)
	{
		if (x <= 1000)
			a[leftTop++] = x;
		else
			a[rightTop--] = x;
		cin >> x;
	}
}
// Definition of function printSmallValues
void printSmallValues(int *a, int leftTop)
{
	cout << "Stack with small values (top): ";
	for (int i = leftTop - 1; i >= 0; i--)
		cout << a[i] << " ";
	cout << endl;
}
// Definition of function printLargeValues
void printLargeValues(int *a, int cap, int rightTop)
{
	cout << "Stack with large values (top): ";
	for (int i = rightTop + 1 ; i < cap; i++)
		cout << a[i] << " ";
	cout << endl;
}