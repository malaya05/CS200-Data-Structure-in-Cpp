#include "HTArray.h"

#include <iostream>
#include <string>
using namespace std;

void searchKey(const HTArray& ht, int key);

int main()
{
	{
		HTArray ht;
		int a[] = { 3, 5, 23, 15, 43 };
		int numOfElem = 5;
		for (int i = 0; i < numOfElem; ++i)
			ht.addElement(a[i]);
		cout << ht << endl;
		int aSearch[] = { 23, 15, 3, 5, 43, 100 };
		int numOfElemSearch = 6;
		for (int i = 0; i < numOfElemSearch; ++i)
			searchKey(ht, aSearch[i]);
	}

	cout << "\n-------------------------------------------\n";

	// These testing cases are given.
	{
		HTArray ht;
		int a[] = { 5, 7, 45, 20, 25 };
		int numOfElem = 5;
		for (int i = 0; i < numOfElem; ++i)
			ht.addElement(a[i]);
		cout << ht << endl;
		int aSearch[] = { 20, 25, 45, 7, 5, 100 };
		int numOfElemSearch = 6;
		for (int i = 0; i < numOfElemSearch; ++i)
			searchKey(ht, aSearch[i]);
	}

	cout << "\n-------------------------------------------\n";

	// These testing cases are for the testing part.

	{
		HTArray ht;
		int a[] = { 123, 456, 789, 741, 856, 963, 370, 257, 150, 633, 793 };
		int numOfElem = 11;
		for (int i = 0; i < numOfElem; ++i)
			ht.addElement(a[i]);
		cout << ht << endl;
		int aSearch[] = { 370, 150, 793, 456, 257, 789, 100 };
		int numOfElemSearch = 7;
		for (int i = 0; i < numOfElemSearch; ++i)
			searchKey(ht, aSearch[i]);
	}

	cout << "\n-------------------------------------------\n";

	{
		HTArray ht(13);
		int a[] = { 123, 456, 789, 741, 856, 963, 370, 257, 150, 633, 793 };
		int numOfElem = 11;
		for (int i = 0; i < numOfElem; ++i)
			ht.addElement(a[i]);
		cout << ht << endl;
		int aSearch[] = { 370, 150, 793, 456, 257, 789, 100 };
		int numOfElemSearch = 7;
		for (int i = 0; i < numOfElemSearch; ++i)
			searchKey(ht, aSearch[i]);
	}

	cout << "\n-------------------------------------------\n";

	cout << endl;
	system("Pause");
	return 0;
}

void searchKey(const HTArray& ht, int key)
{
	if (ht.searchElement(key))
		cout << "Key " << key << " found." << endl;
	else
		cout << "Key " << key << " not found." << endl;
}