#include "Graph.h"

#include <iostream>
#include <string>
#include <vector>
using namespace std;

const string FILE_NAME = "graph_data.txt";

int main()
{
	Graph g1;
	g1.createGraph(FILE_NAME);
	cout << g1 << endl;

	cout << endl;
	system("Pause");
    return 0;
}

