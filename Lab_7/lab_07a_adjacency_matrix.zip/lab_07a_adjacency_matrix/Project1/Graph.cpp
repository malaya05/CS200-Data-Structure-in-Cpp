#include "Graph.h"

// Definition overloaded insertion operator


// Default constructor


// Overloaded constructor


// Definition function createGraph
void Graph::createGraph(const string& fileName)
{
	ifstream infile;

	infile.open(fileName);

	if (!infile)
	{
		cerr << "Cannot open the input file." << endl;
		system("Pause");
		exit(0);
	}

	infile >> numOfVertices;

	// FOR loop to populate the array of characters.
	// Your code here...





	// FOR loop to populate the 2-dimensional array.
	// Your code here...





	infile.close();
}

// Declaration function getNumOfVertices


// Definition function clearGraph


// Destructor
