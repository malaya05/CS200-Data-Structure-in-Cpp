#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include<iostream>
#include <string>		//Need to include for NULL			
using namespace std;

class Node
{
public:
	Node() : data(0), link(nullptr){}
    Node(int theData, Node *theLink) : data(theData), link(theLink){}
    Node* getLink( ) const { return link; }
	int getData( ) const { return data; }
    void setData(int theData) { data = theData; }
    void setLink(Node *theLink) { link = theLink; }
	~Node(){}
private:
    int data;		
    Node *link;	//pointer that points to next node
};


class LinkedList
{
public:
	LinkedList();	
	void insertBack(int);	

	int getCount() const;

	bool search(int element) const;

	void printList() const;

	void emptyTheList();
	~LinkedList();

	// OMITTED (not needed):
	// Copy constructor
	// Overloaded assignment operator

private:
	Node *first; 
	Node *last;  
	int count;	 
};

#endif