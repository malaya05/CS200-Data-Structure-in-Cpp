#include "HTArray.h"

//Definition default constructor
HTArray::HTArray()
{
	capacity = DEFAULT_CAP;
	numOfElements = 0;
	ht = new LinkedList*[capacity];

	// create a linked list for each index
	for (int i = 0; i < capacity; ++i)
	{
		LinkedList *ptrList = new LinkedList;
		ht[i] = ptrList;
	}
}