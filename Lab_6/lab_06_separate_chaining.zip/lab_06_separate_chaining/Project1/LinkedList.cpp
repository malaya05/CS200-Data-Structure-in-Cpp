#include "LinkedList.h"

LinkedList::LinkedList()
{
	first = nullptr;
	last = nullptr;
	count = 0;
}

void LinkedList::insertBack(int newData)
{	
	Node *newNode = new Node(newData, nullptr);	

	if (first == nullptr) first = newNode;
	else last->setLink(newNode);

	last = newNode;
	++count;
}

int LinkedList::getCount() const
{
	return count;
}

bool LinkedList::search(int element) const
{
	if (first == nullptr)
		cerr << "List is empty." << endl;
	else
	{
		Node *current = first;
		while (current != nullptr)
		{
			if (current->getData() == element)
				return true;
			else
				current = current->getLink();
		}
	}

	return false;
}

void LinkedList::printList() const
{
	Node *current;	 
	current = first;	

	while (current != nullptr)	
	{						
		cout << current->getData() << " ";	
		current = current->getLink();		
	}
}

void LinkedList::emptyTheList()
{
	Node  *temp = first;

    while (first != nullptr)
    {
        first = first->getLink();
        delete temp;
		temp = first;
    }

	count = 0;
}

LinkedList::~LinkedList()
{
	emptyTheList();
}

