#include <iostream>
using namespace std;

// Declaration of function processStacks

// Declaration of function printSmallValues

// Declaration of function printLargeValues


int main()
{
	int cap, leftTop, rightTop;

	cout << "Enter max number of integers: ";	
	cin >> cap;

	int *a = new int[cap] ;

	// call to function processStacks

	// call to function printSmallValues

	// call to function printLargeValues

	// what else?

	cout << endl;
	system("Pause");
	return 0;
}

// Definition of function processStacks

// Definition of function printSmallValues

// Definition of function printLargeValues
