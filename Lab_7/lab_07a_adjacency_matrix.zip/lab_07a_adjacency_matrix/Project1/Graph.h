#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

const int MAX_VERTICES = 20;

class Graph
{
	// Declaration overloaded insertion operator 


public:
	// Default constructor


	// Overloaded constructor


	// Declaration function createGraph
	void createGraph(const string& fileName);

	// Declaration function getNumOfVertices


	// Declaration function clearGraph


	// Destructor


private:

	char *vertices;			//will point to an array of vertices
    int **matrix;			//will point to the adjacency matrix
    int maxVertices;		//max number of vertices the graph can hold (capacity)
    int numOfVertices;		//total number of vertices

};

#endif